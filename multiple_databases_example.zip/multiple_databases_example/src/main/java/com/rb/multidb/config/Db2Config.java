package com.rb.multidb.config;

import com.rb.multidb.entity.customer.Customer;
import com.rb.multidb.repository.customer.CustomerRepository;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;
@Configuration
@EnableJpaRepositories(
        basePackageClasses = {CustomerRepository.class}
        ,entityManagerFactoryRef = "db2EntityManager"
        ,transactionManagerRef = "db2TransactionManager"
)
public class Db2Config {

    @Bean
    @ConfigurationProperties("db2")
    public DataSourceProperties secondDataSourceProperties() {
        return new DataSourceProperties();
    }
    @Bean(name = "db2")
    public DataSource second() {
            return secondDataSourceProperties().initializeDataSourceBuilder().build();
    }

    @Bean(name = "db2EntityManager")
    public LocalContainerEntityManagerFactoryBean db2EntityManager(
            EntityManagerFactoryBuilder builder) {
        return builder
                .dataSource(second())
                .packages(Customer.class)
                .persistenceUnit("customer")
                .build();
    }

    @Primary
    @Bean(name = "db2TransactionManager")
    public PlatformTransactionManager db1TransactionManager(
            @Qualifier("db2EntityManager") EntityManagerFactory entityManagerFactoryBean ) {
        JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory(entityManagerFactoryBean);
        return transactionManager;
    }
}
