package com.rb.multidb.service;

import com.rb.multidb.entity.customer.Customer;
import com.rb.multidb.entity.person.Person;
import com.rb.multidb.repository.customer.CustomerRepository;
import com.rb.multidb.repository.person.PersonRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;

@Service
public class SampleService {

    private final PersonRepository personRepository;
    private  final CustomerRepository customerRepository;

    @Autowired
    public SampleService(PersonRepository personRepository, CustomerRepository customerRepository) {
        this.personRepository = personRepository;
        this.customerRepository = customerRepository;
    }

    @Transactional
    public void addPersonAndCustomer() {
        addPerson();
        addCustomer();
    }
    public void addPerson() {
        Person person  = new Person();
        person.setFirstName("FirstName");
        person.setLastName("lastName");
        personRepository.save(person);
    }

    public void addCustomer() {
        Customer person  = new Customer();
        person.setFirstName("FirstName");
        person.setLastName("lastName");
        customerRepository.save(person);
    }
}
