package com.rb.multidb.repository.customer;

import com.rb.multidb.entity.customer.Customer;
import com.rb.multidb.entity.person.Person;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CustomerRepository extends JpaRepository<Customer, Integer> {

}
