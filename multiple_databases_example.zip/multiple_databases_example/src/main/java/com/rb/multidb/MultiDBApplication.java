package com.rb.multidb;

import com.rb.multidb.service.SampleService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class MultiDBApplication {

    public static void main(String[] args) {
        ConfigurableApplicationContext run = SpringApplication.run(MultiDBApplication.class, args);
        SampleService bean = run.getBean(SampleService.class);
        bean.addPersonAndCustomer();
    }

}
