package com.rb.repository.person;

import com.rb.entity.person.Person;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import java.util.List;

@Repository
public class CustomRepo {

    @PersistenceContext(unitName = "person")
    private EntityManager entityManager;

    public List<Person>  finPerson(){
        System.out.println("Entity manager hashcode " +entityManager);;
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Person> query = criteriaBuilder.createQuery(Person.class);
        Root<Person> root = query.from(Person.class);
        query.orderBy(criteriaBuilder.asc(root.get("firstName")));
        return entityManager.createQuery(query).getResultList();

    }
}
