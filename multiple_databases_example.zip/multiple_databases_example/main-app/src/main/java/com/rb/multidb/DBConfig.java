package com.rb.multidb;


import com.ibm.mq.jms.MQConnectionFactory;
import com.ibm.msg.client.jms.JmsConnectionFactory;
import com.rb.config.Db1Config;
import com.rb.config.Db2Config;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Primary;
import org.springframework.jms.connection.JmsTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@Import({ Db1Config.class, Db2Config.class})
@EnableTransactionManagement
public class DBConfig {


    @Bean(name = "tm1")
    @Primary
    public JmsTransactionManager jmsTransactionManager(MQConnectionFactory factory) {
        JmsTransactionManager jmsTransactionManager = new JmsTransactionManager();
        jmsTransactionManager.setConnectionFactory(factory);
        return jmsTransactionManager;
    }
}
