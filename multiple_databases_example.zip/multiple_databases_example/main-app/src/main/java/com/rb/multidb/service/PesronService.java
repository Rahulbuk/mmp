package com.rb.multidb.service;

import com.rb.entity.person.Person;
import com.rb.repository.person.CustomRepo;
import com.rb.repository.person.PersonRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.concurrent.TimeUnit;

@Service
public class PesronService {


    private final CustomRepo repo;
    private final PersonRepository repository;

    @Autowired
    public PesronService(CustomRepo repo, PersonRepository repository) {
        this.repo = repo;
        this.repository = repository;
    }

    @Transactional
    public List<Person> getAllPesons() {
        List<Person> people = repo.finPerson();
        try {
            TimeUnit.SECONDS.sleep(1);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        people.stream()
               .peek(e -> e.setLastName(e.getLastName()+e.getId()))
               .forEach(repository:: save);
    //   throw new IllegalArgumentException("just test");
        return people;
    }
}
