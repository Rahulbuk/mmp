package com.rb.multidb.web;

import com.rb.multidb.service.SampleService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Slf4j
public class PersonController {

    final SampleService sampleService;

    public PersonController(SampleService sampleService) {
        this.sampleService = sampleService;
    }

    @RequestMapping(method = RequestMethod.GET, path = "/{id}", produces = MediaType.TEXT_PLAIN_VALUE)
    public String  getAllPerson(@PathVariable("id") Integer id){
        try {
            sampleService.addPersonAndCustomer(id);
            return "Success";
        }catch (Exception e){
        log.error("Failed ",e);
            return "failed";
        }

    }
}
