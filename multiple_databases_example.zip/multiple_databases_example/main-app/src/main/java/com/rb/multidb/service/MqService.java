package com.rb.multidb.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Slf4j
public class MqService {

    private final JmsTemplate template;

    @Autowired
    public MqService(JmsTemplate template) {
        this.template = template;
    }

    @Transactional
    public<T> void sendPersonOverMq(T object) {
        String s = object.toString();
        log.info("Sending the data to Queue 1 - {}", s);
        template.convertAndSend("DEV.QUEUE.1", s);
    }

    @JmsListener(destination = "DEV.QUEUE.2")
    @Transactional(transactionManager = "tm1")
    public void receiveMessage(String email) {
        System.out.println("Received <" + email + ">");
    }

}
