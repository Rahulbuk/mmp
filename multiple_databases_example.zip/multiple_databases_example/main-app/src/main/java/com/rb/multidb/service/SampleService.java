package com.rb.multidb.service;


import com.rb.entity.customer.Customer;
import com.rb.entity.person.Person;
import com.rb.repository.customer.CustomerRepository;
import com.rb.repository.person.PersonRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class SampleService {

    private final PersonRepository personRepository;
    private  final CustomerRepository customerRepository;
    private  final MqService mqService;

    @Autowired
    public SampleService(PersonRepository personRepository, CustomerRepository customerRepository, MqService mqService) {
        this.personRepository = personRepository;
        this.customerRepository = customerRepository;
        this.mqService = mqService;
    }

    @Transactional(transactionManager = "tm1")
    public void addPersonAndCustomer(Integer id) {
        mqService.sendPersonOverMq(addPerson(id));
        mqService.sendPersonOverMq(addCustomer(id));
    }
    public Person addPerson(Integer id) {
        Person person  = new Person();
        person.setFirstName("FirstName");
        person.setLastName("lastName");
        return personRepository.save(person);
    }

    public Customer addCustomer(Integer id) {
        Customer person  = new Customer();
        person.setFirstName("FirstName");
        person.setLastName("lastName");
        if(id ==2 ){
            throw new IllegalArgumentException("ID2 not allowed to be used");
        }
        return  customerRepository.save(person);
    }
}
