package com.example.demo.repositories.customer;

import com.example.demo.entities.Person;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import javax.persistence.PersistenceUnit;
import javax.persistence.PersistenceUnits;

@Repository
@PersistenceUnits({
        @PersistenceUnit(name = "test")
      //,  @PersistenceUnit(name = "test2")
})
public interface PersonRepo extends CrudRepository<Person, Long> {
}
