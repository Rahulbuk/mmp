package com.example.demo.config;

import com.example.demo.entities.Person;
import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.EclipseLinkJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;
import java.util.Collections;
@Configuration
@EnableJpaRepositories(entityManagerFactoryRef = "customerEntityManagerFactory",
        transactionManagerRef = "chainedTransactionManager"
        ,basePackages = {"com.example.demo.repositories.person"}
)

public class Databaseconfig1 {

    @Bean
    PlatformTransactionManager customerTransactionManager(@Qualifier("customerEntityManagerFactory") LocalContainerEntityManagerFactoryBean managerFactoryBean) {
        return new JpaTransactionManager(managerFactoryBean.getObject());
    }

    @Bean
    LocalContainerEntityManagerFactoryBean customerEntityManagerFactory(@Qualifier("personDataSource")  DataSource dataSource) {

        EclipseLinkJpaVendorAdapter jpaVendorAdapter = new EclipseLinkJpaVendorAdapter();
        jpaVendorAdapter.setGenerateDdl(true);

        LocalContainerEntityManagerFactoryBean factoryBean = new LocalContainerEntityManagerFactoryBean();
        factoryBean.setJpaPropertyMap(Collections.singletonMap("eclipselink.weaving", "false"));
        factoryBean.setDataSource(dataSource);
        factoryBean.setJpaVendorAdapter(jpaVendorAdapter);
        factoryBean.setPackagesToScan(Person.class.getPackage().getName());
        factoryBean.setPersistenceUnitName("test");

        return factoryBean;
    }
    @Bean (name = "personprops")
    @ConfigurationProperties(prefix = "spring.datasource")
    public DataSourceProperties personDataSource(){
        return new DataSourceProperties();
    }


    @Bean("personDataSource")
    @ConfigurationProperties(prefix = "spring.datasource")
    public DataSource persondataSource(@Qualifier("personprops") DataSourceProperties properties){
        return properties.initializeDataSourceBuilder().type(MysqlDataSource.class).build();

    }


    /*@Bean
    @Primary
    @ConfigurationProperties(prefix="spring.datasource")
    public DataSource primaryDataSource() {
        return DataSourceBuilder.create().type(MysqlDataSource.class)
                .driverClassName("com.mysql.jdbc.Driver").password("password")
                .url("jdbc:mysql://localhost:3306/person")
                .username("app").build();
    }*/
}
