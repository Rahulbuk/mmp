package com.example.demo.service;

import com.example.demo.entities.Person;
import com.example.demo.repositories.customer.PersonRepo;
import com.example.demo.repositories.person.PersonRepoTwo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;

@Service
public class PersonService {

    @Autowired

    private PersonRepo personRepo;

    @Autowired
    private PersonRepoTwo repoTwo;

    @Transactional
  public void mainSave(Person p){
        save(p);
        savetow(p);
    }


    public void save(Person p){
        personRepo.save(p);
    }


    @Transactional(value = Transactional.TxType.MANDATORY )
    public void savetow(Person p){
        repoTwo.save(p);
      //  throw new IllegalArgumentException("Checking Trnasactions");
    }

    public Iterable<Person> findAll(){
        return personRepo.findAll();
    }
}
