package com.example.demo.config;

import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.EclipseLinkJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;
import java.util.Collections;

@Configuration
@EnableJpaRepositories(entityManagerFactoryRef = "customerEntityManagerFactory2",
        transactionManagerRef = "chainedTransactionManager"
        , basePackages = {"com.example.demo.repositories.customer"}
)

public class Databaseconfig2 {

    @Bean
    PlatformTransactionManager customerTransactionManager2(@Qualifier("customerEntityManagerFactory2") LocalContainerEntityManagerFactoryBean customerEntityManagerFactory2) {
        return new JpaTransactionManager(customerEntityManagerFactory2.getObject());
    }

    @Bean
    LocalContainerEntityManagerFactoryBean customerEntityManagerFactory2(@Qualifier("customer2") DataSource dataSource) {

        EclipseLinkJpaVendorAdapter jpaVendorAdapter = new EclipseLinkJpaVendorAdapter();
        jpaVendorAdapter.setGenerateDdl(true);

        LocalContainerEntityManagerFactoryBean factoryBean = new LocalContainerEntityManagerFactoryBean();
        factoryBean.setJpaPropertyMap(Collections.singletonMap("eclipselink.weaving", "false"));
        factoryBean.setDataSource(dataSource);
        factoryBean.setJpaVendorAdapter(jpaVendorAdapter);
        // factoryBean.setPackagesToScan(Person.class.getPackage().getName());
        // factoryBean.setPersistenceUnitName("test2");
        factoryBean.setPersistenceXmlLocation("classpath:META-INF/persistence_cust.xml");
        return factoryBean;
    }

   /*@Bean
    DataSource customerDataSource2() {

        return new EmbeddedDatabaseBuilder().//
                setType(EmbeddedDatabaseType.H2).//
                setName("newdB").//
                build();
    }*/


    @Bean(name = "cusProp")
    @ConfigurationProperties(prefix = "spring.seconddatasource")
    public DataSourceProperties dataSourceProperties() {
        return new DataSourceProperties();
    }

    @Bean(name = "customer2")
    public DataSource customerDataSource2_2(@Qualifier("cusProp") DataSourceProperties properties) {

        return properties.initializeDataSourceBuilder().type(MysqlDataSource.class).build();
        /*return DataSourceBuilder.create()
                .type(MysqlDataSource.class)
                .driverClassName("com.mysql.jdbc.Driver")
                .password("password")
                .url("jdbc:mysql://localhost:3306/customer")
                .username("app")
                .build();*/
    }
}
