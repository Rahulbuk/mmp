package com.example.demo.repositories.person;

import com.example.demo.entities.Person;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import javax.persistence.PersistenceUnit;

@Repository
@PersistenceUnit(name = "test2")
public interface PersonRepoTwo extends CrudRepository<Person, Long>
{
}
