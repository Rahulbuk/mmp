package com.example.demo.controller;

import com.example.demo.entities.Person;
import com.example.demo.service.PersonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PersonController {

    @Autowired
    PersonService service;

    @RequestMapping(path = "person", method = RequestMethod.GET)
    public Iterable<Person> getAllPerson(){
        return service.findAll();
    }

    @RequestMapping(path = "create", method = RequestMethod.GET)
    public void createc(){
         service.mainSave(new Person("NEw Person ","B"));
    }



}
